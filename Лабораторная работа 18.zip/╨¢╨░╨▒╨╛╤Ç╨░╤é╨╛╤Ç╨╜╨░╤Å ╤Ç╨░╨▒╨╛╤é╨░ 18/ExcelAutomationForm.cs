using System.Reflection;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAutomationApp
{
    public partial class ExcelAutomationForm : Form
    {
        string[] csvData;

        public ExcelAutomationForm()
        {
            InitializeComponent();
            csvData = File.ReadAllText("defaulData.csv", System.Text.Encoding.UTF8).Split(',');
            for (int i = 0; i < csvData.Length; i += 9)
                PreviewDGV.Rows.Add(csvData.Take(new Range(i, i + 9)).ToArray());
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            Excel.Application app = new Excel.Application();
            app.Visible = false;
            Excel.Workbook wb = app.Workbooks.Add(Missing.Value);
            Excel.Worksheet ws = wb.Sheets.Add();
            ws.Activate();

            ws.Range["A1", "A2"].Merge();
            ws.Cells[1, 1] = "���� ������";
            ws.Range["A1", "A2"].ColumnWidth = 10f;

            ws.Range["B1", "C1"].Merge();
            ws.Cells[1, 2] = "�����";
            ws.Cells[2, 2] = "���������";
            ws.Cells[2, 3] = "�� �������";

            ws.Range["D1", "D2"].Merge();
            ws.Range["D1", "D2"].ColumnWidth = 40f;
            ws.Cells[1, 4] = "�� ���� �������� ��� ���� ����������";

            ws.Range["E1", "E2"].Merge();
            ws.Range["E1", "E2"].ColumnWidth = 18f;
            ws.Cells[1, 5] = "������� ������� ������� ��������� (�����, �����)";
            ws.Range["F1", "F2"].Merge();
            ws.Cells[1, 6] = "������";
            ws.Range["G1", "G2"].Merge();
            ws.Cells[1, 7] = "������";
            ws.Range["H1", "H2"].Merge();
            ws.Cells[1, 8] = "�������";
            ws.Range["I1", "I2"].Merge();
            ws.Cells[1, 9] = "�������, ����";
            ws.Range["F1", "I1"].ColumnWidth = 11f;

            for (int i = 1; i < 10; i++)
            {
                ws.Cells[3, i] = i;
            }

            Excel.Range r = ws.Range["A1", "I7"];
            r.WrapText = true;
            r.HorizontalAlignment = Excel.Constants.xlCenter;
            r.VerticalAlignment = Excel.Constants.xlCenter;
            r.Borders.Weight = 2;
            ws.Range["H4", "H7"].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 4;
            ws.Range["H4", "H7"].Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = 4;
            ws.Range["H4", "H7"].Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 4;
            ws.Range["H4", "H7"].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 4;

            for (int i = 0; i < csvData.Length; i++)
            {
                ws.Cells[4 + i / 9, 1 + i % 9] = csvData[i];
            }


            app.UserControl = true;
            wb.SaveCopyAs(Application.StartupPath + Name + ".xlsx");
            wb.Close(false);
        }
    }
}
