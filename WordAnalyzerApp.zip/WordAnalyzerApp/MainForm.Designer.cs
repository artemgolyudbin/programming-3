﻿namespace WordAnalyzerApp
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.ImportDocumentButton = new System.Windows.Forms.Button();
            this.ConvertToWord = new System.Windows.Forms.Button();
            this.openWordDialog = new System.Windows.Forms.OpenFileDialog();
            this.openCsvDialog = new System.Windows.Forms.OpenFileDialog();
            this.ChartComboBox = new System.Windows.Forms.ComboBox();
            this.YearNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.MainChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.YearNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainChart)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(356, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Графический анализ данных";
            // 
            // ImportDocumentButton
            // 
            this.ImportDocumentButton.Location = new System.Drawing.Point(13, 12);
            this.ImportDocumentButton.Name = "ImportDocumentButton";
            this.ImportDocumentButton.Size = new System.Drawing.Size(100, 43);
            this.ImportDocumentButton.TabIndex = 1;
            this.ImportDocumentButton.Text = "Импортировать документ";
            this.ImportDocumentButton.UseVisualStyleBackColor = true;
            this.ImportDocumentButton.Click += new System.EventHandler(this.ImportDocumentButton_Click);
            // 
            // ConvertToWord
            // 
            this.ConvertToWord.Location = new System.Drawing.Point(13, 61);
            this.ConvertToWord.Name = "ConvertToWord";
            this.ConvertToWord.Size = new System.Drawing.Size(100, 42);
            this.ConvertToWord.TabIndex = 3;
            this.ConvertToWord.Text = "Восстановить Word из CSV";
            this.ConvertToWord.UseVisualStyleBackColor = true;
            this.ConvertToWord.Click += new System.EventHandler(this.ConvertToWord_Click);
            // 
            // openWordDialog
            // 
            this.openWordDialog.FileName = "openFileDialog";
            this.openWordDialog.Filter = "Файлы Word | *.doc;*.docx";
            this.openWordDialog.Title = "Выбрать документ";
            // 
            // openCsvDialog
            // 
            this.openCsvDialog.Filter = "CSV-файл|*.csv";
            // 
            // ChartComboBox
            // 
            this.ChartComboBox.FormattingEnabled = true;
            this.ChartComboBox.Items.AddRange(new object[] {
            "Количество дней, проведённых на больничном преподавателями за весь известный пери" +
                "од",
            "Количество дней, проведённых на больничном преподавателями за указанный год",
            "Общее количество часов, заменённых преподавателями по болезни",
            "Количество часов практических занятий, заменённых преподавателями по болезни",
            "Количество часов лабораторных работ, заменённых преподавателями по болезни",
            "Количество часов лекций, заменённых преподавателями по болезни",
            "Общее количество дней, в которые замещающие преподаватели осуществляли замены за " +
                "весь известный период",
            "Общее количество дней, в которые замещающие преподаватели осуществляли замены за " +
                "указанный год."});
            this.ChartComboBox.Location = new System.Drawing.Point(13, 417);
            this.ChartComboBox.Name = "ChartComboBox";
            this.ChartComboBox.Size = new System.Drawing.Size(687, 21);
            this.ChartComboBox.TabIndex = 4;
            this.ChartComboBox.Text = "Количество дней, проведённых на больничном преподавателями за весь известный пери" +
    "од";
            this.ChartComboBox.SelectedIndexChanged += new System.EventHandler(this.ChartComboBox_SelectedIndexChanged);
            // 
            // YearNumericUpDown
            // 
            this.YearNumericUpDown.Location = new System.Drawing.Point(706, 417);
            this.YearNumericUpDown.Maximum = new decimal(new int[] {
            2025,
            0,
            0,
            0});
            this.YearNumericUpDown.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.YearNumericUpDown.Name = "YearNumericUpDown";
            this.YearNumericUpDown.Size = new System.Drawing.Size(82, 20);
            this.YearNumericUpDown.TabIndex = 5;
            this.YearNumericUpDown.Value = new decimal(new int[] {
            2025,
            0,
            0,
            0});
            this.YearNumericUpDown.ValueChanged += new System.EventHandler(this.YearNumericUpDown_ValueChanged);
            // 
            // MainChart
            // 
            chartArea1.Name = "ChartArea1";
            this.MainChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.MainChart.Legends.Add(legend1);
            this.MainChart.Location = new System.Drawing.Point(119, 29);
            this.MainChart.Name = "MainChart";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.MainChart.Series.Add(series1);
            this.MainChart.Size = new System.Drawing.Size(669, 382);
            this.MainChart.TabIndex = 6;
            this.MainChart.Text = "MainChart";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainChart);
            this.Controls.Add(this.YearNumericUpDown);
            this.Controls.Add(this.ChartComboBox);
            this.Controls.Add(this.ConvertToWord);
            this.Controls.Add(this.ImportDocumentButton);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "Электронный документооборот";
            ((System.ComponentModel.ISupportInitialize)(this.YearNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ImportDocumentButton;
        private System.Windows.Forms.Button ConvertToWord;
        private System.Windows.Forms.OpenFileDialog openWordDialog;
        private System.Windows.Forms.OpenFileDialog openCsvDialog;
        private System.Windows.Forms.ComboBox ChartComboBox;
        private System.Windows.Forms.NumericUpDown YearNumericUpDown;
        private System.Windows.Forms.DataVisualization.Charting.Chart MainChart;
    }
}

