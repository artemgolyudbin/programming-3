﻿using System;

namespace WordAnalyzerApp
{
    class Substitution
    {
        public string Person;
        public DateTime date;
        public string ClassType;
        public string Group;

        public Substitution(string person, DateTime date, string classType, string group)
        {
            Person = person;
            this.date = date;
            ClassType = classType;
            Group = group;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Substitution))
                return false;

            Substitution other = (Substitution)obj;
            return this.Person == other.Person && this.date == other.date && this.ClassType == other.ClassType && this.Group == other.Group;
        }
    }
}