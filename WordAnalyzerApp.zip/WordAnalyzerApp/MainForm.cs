﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;
using Series = System.Windows.Forms.DataVisualization.Charting.Series;

namespace WordAnalyzerApp
{
    public partial class MainForm: Form
    {
        private Dictionary<string, List<Substitution>> AllData = new Dictionary<string, List<Substitution>>();

        public MainForm()
        {
            InitializeComponent();
        }

        private void ImportDocumentButton_Click(object sender, EventArgs e)
        {
            if (openWordDialog.ShowDialog() == DialogResult.OK)
            {
                ConvertToCSV(openWordDialog.FileName);
                ConvertCSVToExcel(Path.GetDirectoryName(openWordDialog.FileName) + "\\" + Path.GetFileNameWithoutExtension(openWordDialog.FileName) + ".csv");
                ChartComboBox_SelectedIndexChanged(this, null);
            }
        }

        private void ConvertToWord_Click(object sender, EventArgs e)
        {
            if (openCsvDialog.ShowDialog() == DialogResult.OK)
            {
                ConvertCsvToWord(openCsvDialog.FileName);
            }
        }

        private string GetTextPart(string text, string from, string to)
        {
            int fromIndex = text.IndexOf(from) + from.Length;
            return text.Substring(fromIndex, text.Substring(fromIndex).IndexOf(to));
        }

        private void ChartComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ChartComboBox.SelectedIndex == 0)
                UpdateChart(AllData.Select(kvp => new Tuple<string, float>(kvp.Key, kvp.Value.Select(l => l.date).Distinct().Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 1)
                UpdateChart(AllData.Select(kvp => new Tuple<string, float>(kvp.Key, kvp.Value.Select(l => l.date).Where(d => d.Year == YearNumericUpDown.Value).Distinct().Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 2)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count() * 2)).ToArray());
            else if (ChartComboBox.SelectedIndex == 3)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Where(s => s.ClassType.StartsWith("практ")).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 4)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Where(s => s.ClassType.StartsWith("лаб")).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 5)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Where(s => s.ClassType.StartsWith("лек")).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 6)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count())).ToArray());
            else if (ChartComboBox.SelectedIndex == 7)
                UpdateChart(AllData.Select(kvp => kvp.Value).Aggregate((l1, l2) => l1.Concat(l2).ToList()).Where(s => s.date.Year == YearNumericUpDown.Value).Select(s => new Tuple<string, float>(s.Person, 2)).GroupBy(t => t.Item1).Select(t => new Tuple<string, float>(t.Key, t.Count())).ToArray());
        }

        private void YearNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            ChartComboBox_SelectedIndexChanged(this, null);
        }

        private void ConvertToCSV(string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Выберите файл!");
                return;
            }

            string pathToCSV = Path.GetDirectoryName(filePath) + "\\" + Path.GetFileNameWithoutExtension(filePath) + ".csv";

            Word.Application oWord = new Word.Application();
            Word.Document oDoc = null;
            oDoc = oWord.Documents.Open(filePath, ReadOnly: true);

            using (StreamWriter writer = new StreamWriter(pathToCSV, false, Encoding.UTF8))
            {
                //Создаем оглавление CSV
                string[] headers = { "\"Кому", "По болезни", "Период", "Кафедра", "Подпись", "Б/л", "Заменяющий", "Дата", "Занятие", "Группа\"" };
                writer.WriteLine(string.Join("\",\t\"", headers));

                //Записываем весь файл в строку
                StringBuilder sb = new StringBuilder();
                foreach (Word.Paragraph p in oDoc.Paragraphs)
                    if (!string.IsNullOrEmpty(p.Range.Text.Trim()))
                        sb.AppendLine(p.Range.Text.Trim());

                string text = sb.ToString();

                //Заполнение информации, содержащейся в одной строке
                writer.Write("\"" + text.Substring(0, text.ToLower().IndexOf("рапорт")).Replace(Environment.NewLine, " ").Trim() + "\",\t");
                writer.Write("\"" + Regex.Replace(GetTextPart(text, "В связи с болезнью ", " с "), " в период", "") + "\",\t");
                writer.Write("\"" + GetTextPart(GetTextPart(text, "В связи с болезнью ", "(") + "(", " с ", " (") + "\",\t");
                writer.Write("\"" + GetTextPart(text, "«", "»") + "\",\t");
                string signature = text.Split('\n').Last(s => !string.IsNullOrWhiteSpace(s) && s.Trim() != "\a").Trim('\a', '\r').Trim();
                writer.Write("\"" + signature + "\",\t");

                //Сохранение больничных листов
                List<long> b_lists = GetTextPart(text, "№", ")").Split(',').Select(s => long.Parse(Regex.Replace(s.Replace("№", ""), @"\s", "").Split('о')[0])).ToList();
                writer.Write(b_lists[0] + ",\t");
                //Сохранение данных о заменах
                List<Substitution> substitutions = new List<Substitution>();
                string[] substitutionsText = text.Substring(text.IndexOf("зки:") + 4).Split('\n');
                string person = "";
                foreach (string s in substitutionsText)
                {
                    if (s.Length < 2)
                        continue;

                    if (char.IsDigit(s[1]))
                    {
                        DateTime date;
                        if (!DateTime.TryParse(s.Substring(0, 8), out date))
                        {
                            MessageBox.Show("Некорректная дата (" + s.Substring(0, 8) + ") пропущена");
                            continue;
                        }

                        string type = s.Substring(10).Split(' ').First(_s => !string.IsNullOrEmpty(_s) && char.IsLetter(_s[0]));
                        substitutions.Add(new Substitution(person, date, type, Regex.Match(s, @"\b[А-Я]{3}-\d{1,}\b").Value));
                        continue;
                    }

                    if (s.StartsWith("Всего:"))
                        continue;

                    person = Regex.Replace(s, @"\d.", "").Trim();
                }

                string[] _n = Path.GetFileNameWithoutExtension(filePath).Substring(9).Split('_');
                string name = _n[0] + " " + _n[1] + ". " + _n[2] + ".";
                if (!AllData.ContainsKey(name))
                    AllData.Add(name, new List<Substitution>());

                AllData[name].AddRange(substitutions);

                writer.Write(substitutions[0].Person + ",\t" + substitutions[0].date.ToShortDateString() + ",\t" + substitutions[0].ClassType + ",\t" + substitutions[0].Group + "\n");

                int rows_amount = Math.Max(b_lists.Count, substitutions.Count);
                for (int i = 1; i < rows_amount; i++)
                    writer.WriteLine(",\t,\t,\t,\t,\t" + (b_lists.Count > i ? b_lists[i].ToString() : "") + ",\t"
                        + (substitutions.Count > i ? (substitutions[i].Person + ",\t" + substitutions[i].date.ToShortDateString() + ",\t" + substitutions[i].ClassType + ",\t" + substitutions[i].Group + "")
                        : ",\t,\t,\t"));
            }

            MessageBox.Show("Данные успешно записаны в CSV!");
            oDoc.Close();
            oWord.Quit();
        }

        private void ConvertCSVToExcel(string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Выберите файл!");
                return;
            }

            string pathToExcel = Path.GetDirectoryName(filePath) + "\\" + Path.GetFileNameWithoutExtension(filePath) + ".xlsx";

            Excel.Application oExcel = new Excel.Application();
            Excel.Workbook workbook = oExcel.Workbooks.Add();
            Excel.Worksheet worksheet = workbook.Worksheets[1];

            //Записываем весь файл в строку
            string text = File.ReadAllText(filePath, Encoding.UTF8);
            string[][] cells = text.Split('\n').Select(s => new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))").Split(s).Select(s1 => s1.Trim().Trim('\"')).ToArray()).ToArray();
            for (int i = 0; i < cells.Length; i++)
                for(int j = 0; j < cells.Max(col => col.Length); j++)
                {
                    try
                    {
                        worksheet.Cells[i + 1, j + 1] = cells[i][j].Trim('\"', '\t');
                    }
                    catch (Exception e) { }
                }

            File.Delete(pathToExcel);
            // Сохранение Excel файла
            workbook.SaveAs(pathToExcel);

            // Закрываем книгу без сохранения
            workbook.Close(false);
            oExcel.Quit();

            MessageBox.Show("Данные успешно записаны в Excel!");
        }

        private void ConvertCsvToWord(string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Выберите файл!");
                return;
            }

            string pathToWord = Path.GetDirectoryName(filePath) + "\\" + Path.GetFileNameWithoutExtension(filePath) + "_restored.docx";

            Word.Application oWord = new Word.Application();
            Word.Document oDoc = oWord.Documents.Add();
                
            //Записываем весь файл в строку
            string text = File.ReadAllText(filePath, Encoding.UTF8);
            string[][] cells = text.Split('\n').Select(s => new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))").Split(s).Select(s1 => s1.Trim().Trim('\"')).ToArray()).ToArray();

            Word.Paragraph oPr = oDoc.Paragraphs.Add();
            oPr.Range.Font.Size = 12;
            oPr.Range.Text = cells[1][0];
            oPr.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
            oPr.Range.Text += "\n\n\n";

            oPr.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            oPr.Range.Font.Size = 12;
            oPr.Range.InsertParagraphAfter();
            oPr.Range.Text = "Рапорт\n";

            oPr.Range.Font.Size = 12;
            oPr.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            oPr.Range.InsertParagraphAfter();

            List<long> b_lists = new List<long>();
            for (int i = 1; i < cells.Length - 1; i++)
            {
                if (!long.TryParse(cells[i][5], out _))
                    continue;

                b_lists.Add(long.Parse(cells[i][5]));
            }

            oPr.Range.Text = "\tВ связи с болезнью " + cells[1][1] + " в период с " + cells[1][2]
                + " (больничные листы: " + b_lists.Select(bl => bl.ToString("№000 000 000 000")).Aggregate((s1, s2) => s1 + ", " + s2) + ")"
                + " на кафедре «" + cells[1][3] + "» производились замены занятий в счет бюджетной нагрузки:";

            List<Substitution> substitutions = new List<Substitution>();
            for (int i = 1; i < cells.Length - 1; i++)
            {
                substitutions.Add(new Substitution(cells[i][6], DateTime.Parse(cells[i][7]), cells[i][8], cells[i][9]));
            }

            substitutions = substitutions.OrderBy(sub => sub.Person).ToList();

            int subPersonCount = 0;
            string person = string.Empty;
            for(int i = 0; i < substitutions.Count; i++)
            {
                if (person != substitutions[i].Person)
                {
                    if (person != string.Empty)
                        oPr.Range.Text += "\t\t                                                             "
                            + "Всего: " + (substitutions.Where(sub => sub.Person == person).Count() * 2);

                    person = substitutions[i].Person;
                    subPersonCount++;
                    oPr.Range.Font.Size = 12;
                    oPr.Range.InsertParagraphAfter();
                    oPr.Range.Text = "\n\t\t" + subPersonCount + ". " + substitutions[i].Person;
                    oPr.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                }

                oPr.Range.Text += "\t\t                                                             "
                    + substitutions[i].date.ToString("dd.MM.yy") + "г. " + substitutions[i].ClassType + " " + substitutions[i].Group + " – 2ч.";
            }

            oPr.Range.Text += "\t\t                                                             "
                + "Всего: " + (substitutions.Where(sub => sub.Person == person).Count() * 2) + "\n";

            oPr.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
            oPr.Range.InsertParagraphAfter();
            oPr.Range.Text = cells[1][4];
            oDoc.SaveAs2(pathToWord);
            oWord.Quit();

            MessageBox.Show("Документ восстановлен!");
        }

        private void UpdateChart(Tuple<string, float>[] data)
        {
            if (data.Length > 0)
            {
                float max = data.Select(d => d.Item2).Max();
                MainChart.ChartAreas[0].AxisY.Maximum = max + (max / 6) + 2;
            }

            Series SL = new Series
            {
                IsValueShownAsLabel = false,
                ChartType = SeriesChartType.Column,
                BorderColor = Color.Black,
                BorderWidth = 1,
                IsVisibleInLegend = false
            };

            MainChart.ChartAreas[0].AxisX.CustomLabels.Clear();
            for (int i = 0; i < data.Length; i++)
            {
                MainChart.ChartAreas[0].AxisX.CustomLabels.Add(i + 0.5, i + 1.5, data[i].Item1);
                SL.Points.AddXY(i + 1, data[i].Item2);
            }

            MainChart.Series.Clear();
            MainChart.Series.Add(SL);
        }
    }
}