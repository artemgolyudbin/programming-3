﻿namespace DiagrammApp
{
    partial class DiagramForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.StolbChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.LinChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.RBStolb = new System.Windows.Forms.RadioButton();
            this.RBLin = new System.Windows.Forms.RadioButton();
            this.RBBoth = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSwap = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.numericUpDownResult = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.StolbChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResult)).BeginInit();
            this.SuspendLayout();
            // 
            // StolbChart
            // 
            this.StolbChart.AntiAliasing = System.Windows.Forms.DataVisualization.Charting.AntiAliasingStyles.None;
            chartArea1.AlignmentStyle = System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.None;
            chartArea1.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Auto;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX2.MajorGrid.Enabled = false;
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.LabelAutoFitMaxFontSize = 8;
            chartArea1.AxisY.LabelAutoFitMinFontSize = 8;
            chartArea1.AxisY.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MajorGrid.Interval = 500D;
            chartArea1.AxisY.MajorGrid.IntervalOffset = 15D;
            chartArea1.AxisY.MajorGrid.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MajorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea1.AxisY.MinorGrid.Interval = 50D;
            chartArea1.AxisY.MinorGrid.IntervalOffset = 50D;
            chartArea1.AxisY.MinorGrid.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MinorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea1.AxisY.MinorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea1.AxisY.ScaleView.Zoomable = false;
            chartArea1.AxisY.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea1.AxisY.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea1.AxisY2.LabelStyle.Enabled = false;
            chartArea1.AxisY2.MaximumAutoSize = 10F;
            chartArea1.AxisY2.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea1.AxisY2.Title = "фыв";
            chartArea1.AxisY2.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea1.Name = "ChartArea1";
            this.StolbChart.ChartAreas.Add(chartArea1);
            this.StolbChart.Location = new System.Drawing.Point(12, 12);
            this.StolbChart.Name = "StolbChart";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.StolbChart.Series.Add(series1);
            this.StolbChart.Size = new System.Drawing.Size(367, 300);
            this.StolbChart.TabIndex = 0;
            this.StolbChart.Text = "chart1";
            title1.Alignment = System.Drawing.ContentAlignment.TopCenter;
            title1.Name = "Title1";
            title1.Text = "Столбчатая диаграмма";
            title1.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            this.StolbChart.Titles.Add(title1);
            // 
            // LinChart
            // 
            this.LinChart.AntiAliasing = System.Windows.Forms.DataVisualization.Charting.AntiAliasingStyles.None;
            chartArea2.AlignmentStyle = System.Windows.Forms.DataVisualization.Charting.AreaAlignmentStyles.None;
            chartArea2.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Auto;
            chartArea2.AxisX.MajorGrid.Enabled = false;
            chartArea2.AxisX2.MajorGrid.Enabled = false;
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.LabelAutoFitMaxFontSize = 8;
            chartArea2.AxisY.LabelAutoFitMinFontSize = 8;
            chartArea2.AxisY.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MajorGrid.Interval = 500D;
            chartArea2.AxisY.MajorGrid.IntervalOffset = 15D;
            chartArea2.AxisY.MajorGrid.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MajorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea2.AxisY.MinorGrid.Interval = 50D;
            chartArea2.AxisY.MinorGrid.IntervalOffset = 50D;
            chartArea2.AxisY.MinorGrid.IntervalOffsetType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MinorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.MinorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea2.AxisY.ScaleView.Zoomable = false;
            chartArea2.AxisY.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea2.AxisY.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea2.AxisY2.LabelStyle.Enabled = false;
            chartArea2.AxisY2.MaximumAutoSize = 10F;
            chartArea2.AxisY2.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            chartArea2.AxisY2.Title = "фыв";
            chartArea2.AxisY2.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea2.Name = "ChartArea1";
            this.LinChart.ChartAreas.Add(chartArea2);
            this.LinChart.Location = new System.Drawing.Point(421, 12);
            this.LinChart.Name = "LinChart";
            series2.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series2.ChartArea = "ChartArea1";
            series2.CustomProperties = "MaxPixelPointWidth=2";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.LinChart.Series.Add(series2);
            this.LinChart.Size = new System.Drawing.Size(367, 300);
            this.LinChart.TabIndex = 1;
            this.LinChart.Text = "chart1";
            title2.Alignment = System.Drawing.ContentAlignment.TopCenter;
            title2.Name = "Title1";
            title2.Text = "Линейная диаграмма";
            title2.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal;
            this.LinChart.Titles.Add(title2);
            // 
            // RBStolb
            // 
            this.RBStolb.AutoSize = true;
            this.RBStolb.Location = new System.Drawing.Point(12, 355);
            this.RBStolb.Name = "RBStolb";
            this.RBStolb.Size = new System.Drawing.Size(143, 17);
            this.RBStolb.TabIndex = 2;
            this.RBStolb.Text = "Столбчатая диаграмма";
            this.RBStolb.UseVisualStyleBackColor = true;
            this.RBStolb.CheckedChanged += new System.EventHandler(this.RBStolb_CheckedChanged);
            // 
            // RBLin
            // 
            this.RBLin.AutoSize = true;
            this.RBLin.Location = new System.Drawing.Point(12, 379);
            this.RBLin.Name = "RBLin";
            this.RBLin.Size = new System.Drawing.Size(135, 17);
            this.RBLin.TabIndex = 3;
            this.RBLin.Text = "Линейная диаграмма";
            this.RBLin.UseVisualStyleBackColor = true;
            this.RBLin.CheckedChanged += new System.EventHandler(this.RBLin_CheckedChanged);
            // 
            // RBBoth
            // 
            this.RBBoth.AutoSize = true;
            this.RBBoth.Checked = true;
            this.RBBoth.Location = new System.Drawing.Point(12, 403);
            this.RBBoth.Name = "RBBoth";
            this.RBBoth.Size = new System.Drawing.Size(107, 17);
            this.RBBoth.TabIndex = 4;
            this.RBBoth.TabStop = true;
            this.RBBoth.Text = "Обе диаграммы";
            this.RBBoth.UseVisualStyleBackColor = true;
            this.RBBoth.CheckedChanged += new System.EventHandler(this.RBBoth_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 339);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Режим отображения";
            // 
            // buttonSwap
            // 
            this.buttonSwap.Location = new System.Drawing.Point(12, 438);
            this.buttonSwap.Name = "buttonSwap";
            this.buttonSwap.Size = new System.Drawing.Size(143, 45);
            this.buttonSwap.TabIndex = 6;
            this.buttonSwap.Text = "Поменять диаграммы местами";
            this.buttonSwap.UseVisualStyleBackColor = true;
            this.buttonSwap.Click += new System.EventHandler(this.buttonSwap_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(668, 355);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(120, 20);
            this.textBoxName.TabIndex = 7;
            // 
            // numericUpDownResult
            // 
            this.numericUpDownResult.Location = new System.Drawing.Point(668, 403);
            this.numericUpDownResult.Name = "numericUpDownResult";
            this.numericUpDownResult.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownResult.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(665, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Имя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(665, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Результат, мин";
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(713, 431);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 11;
            this.buttonAdd.Text = "Добавить";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(713, 460);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonDelete.TabIndex = 12;
            this.buttonDelete.Text = "Удалить";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 496);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numericUpDownResult);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.buttonSwap);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RBBoth);
            this.Controls.Add(this.RBLin);
            this.Controls.Add(this.RBStolb);
            this.Controls.Add(this.LinChart);
            this.Controls.Add(this.StolbChart);
            this.Name = "Form1";
            this.Text = "Задание №20 выполнил: Голюбдин А.В., Номер варианта: 3 Дата выполнения: 25/12/202" +
    "4";
            ((System.ComponentModel.ISupportInitialize)(this.StolbChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LinChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart StolbChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart LinChart;
        private System.Windows.Forms.RadioButton RBStolb;
        private System.Windows.Forms.RadioButton RBLin;
        private System.Windows.Forms.RadioButton RBBoth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonSwap;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.NumericUpDown numericUpDownResult;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonDelete;
    }
}

