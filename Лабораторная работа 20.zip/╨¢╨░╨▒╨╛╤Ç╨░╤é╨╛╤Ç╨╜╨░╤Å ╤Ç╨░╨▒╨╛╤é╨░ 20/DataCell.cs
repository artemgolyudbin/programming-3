﻿namespace DiagrammApp
{
    public class DataCell
    {
        public string Name { get; set; }
        public float Value { get; set; }

        public DataCell(string name, float value)
        {
            Name = name;
            Value = value;
        }
    }
}