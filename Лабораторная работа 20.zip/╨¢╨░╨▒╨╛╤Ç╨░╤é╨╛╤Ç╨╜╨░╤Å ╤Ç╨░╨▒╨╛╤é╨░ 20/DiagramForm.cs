﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace DiagrammApp
{
    public partial class DiagramForm : Form
    {
        private List<DataCell> data = new List<DataCell>();

        public DiagramForm()
        {
            InitializeComponent();

            data = File.ReadAllText("Data.csv", System.Text.Encoding.UTF8).Split('\n').Select(s => new DataCell(s.Split(',')[0], float.Parse(s.Split(',')[1]))).ToList();
            UpdateChart();
        }

        private void UpdateChart()
        {
            float max = data.Select(d => d.Value).Max();
            float step = max / 6;

            StolbChart.ChartAreas[0].AxisY.CustomLabels.Clear();
            for (float i = 0;  i <= max; i += step)
                StolbChart.ChartAreas[0].AxisY.CustomLabels.Add(i - 1, i + 1, i.ToString());

            StolbChart.ChartAreas[0].AxisY.CustomLabels.Add(max + step + 1, max  + step + 3, "Время");
            StolbChart.ChartAreas[0].AxisY.CustomLabels.Add(max + step - 1, max  + step + 1, "в мин");
            StolbChart.ChartAreas[0].AxisY.MajorGrid.IntervalOffset = max / 2;
            StolbChart.ChartAreas[0].AxisY.Maximum = max + step + 2;

            LinChart.ChartAreas[0].AxisY.CustomLabels.Clear();
            for (float i = 0;  i <= max; i += step)
                LinChart.ChartAreas[0].AxisY.CustomLabels.Add(i - 1, i + 1, i.ToString());

            LinChart.ChartAreas[0].AxisY.CustomLabels.Add(max + step + 1, max  + step + 3, "Время");
            LinChart.ChartAreas[0].AxisY.CustomLabels.Add(max + step - 1, max  + step + 1, "в мин");
            LinChart.ChartAreas[0].AxisY.MajorGrid.IntervalOffset = max / 2;
            LinChart.ChartAreas[0].AxisY.Maximum = max + step + 2;

            Series SL = new Series
            {
                IsValueShownAsLabel = false,
                ChartType = SeriesChartType.Column,
                BorderColor = Color.Black,
                BorderWidth = 1,
                IsVisibleInLegend = false
            };

            Series SR = new Series
            {
                IsValueShownAsLabel = false,
                ChartType = SeriesChartType.Column,
                IsVisibleInLegend = false
            };

            SR["PixelPointWidth"] = "2";

            StolbChart.ChartAreas[0].AxisX.CustomLabels.Clear();
            LinChart.ChartAreas[0].AxisX.CustomLabels.Clear();
            for (int i = 0; i < data.Count; i++)
            {
                StolbChart.ChartAreas[0].AxisX.CustomLabels.Add(i + 0.2, i + 1.2, data[i].Name);
                LinChart.ChartAreas[0].AxisX.CustomLabels.Add(i + 0.5, i + 1.5, data[i].Name);
            }

            for (int i = 0; i < data.Count; i++)
            {
                SL.Points.AddXY(i + 1, data[i].Value);
                SL.Points[i].Color = Color.LightGoldenrodYellow;
                SR.Points.AddXY(i + 1, data[i].Value);
                SR.Points[i].Color = Color.Black;
            }

            StolbChart.Series.Clear();
            StolbChart.Series.Add(SL);

            LinChart.Series.Clear();
            LinChart.Series.Add(SR);
        }

        private void SaveData()
        {
            File.WriteAllText("Data.csv", data.Select(d => d.Name + ',' + d.Value).Aggregate((s1, s2) => s1 + '\n' + s2), System.Text.Encoding.UTF8);
        }

        private void RBStolb_CheckedChanged(object sender, EventArgs e)
        {
            StolbChart.Visible = true;
            LinChart.Visible = false;
        }

        private void RBLin_CheckedChanged(object sender, EventArgs e)
        {
            StolbChart.Visible = false;
            LinChart.Visible = true;
        }

        private void RBBoth_CheckedChanged(object sender, EventArgs e)
        {
            StolbChart.Visible = true;
            LinChart.Visible = true;
        }

        private void buttonSwap_Click(object sender, EventArgs e)
        {
            Point location = StolbChart.Location;
            StolbChart.Location = LinChart.Location;
            LinChart.Location = location;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxName.Text) || numericUpDownResult.Value <= 0)
            {
                MessageBox.Show("Неверно заполнены данные!");
                return;
            }

            data.Add(new DataCell(textBoxName.Text, (float)numericUpDownResult.Value));
            SaveData();
            UpdateChart();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            DataCell dataCell = data.FirstOrDefault(data => data.Name == textBoxName.Text);
            if (dataCell == null)
            {
                MessageBox.Show("Запись не найдена!");
                return;
            }

            data.Remove(dataCell);
            SaveData();
            UpdateChart();
        }
    }
}