﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace LINQ
{
    public partial class MainForm : Form
    {
        private List<Person> people = new List<Person>();
        public MainForm()
        {
            InitializeComponent();
            string[] csvData = File.ReadAllText("People.csv", System.Text.Encoding.UTF8).Split(',');
            for (int i = 0; i < csvData.Length; i += 2)
                people.Add(new Person(csvData[i], csvData[i + 1] == "t"));
            csvData = File.ReadAllText("Busies.csv", System.Text.Encoding.UTF8).Split(',');
            for (int i = 0; i < csvData.Length; i += 4)
                people.Find(p => p.Name == csvData[i + 3]).busies.Add(new BusyType((BusyType.Type) int.Parse(csvData[i]), csvData[i + 1], int.Parse(csvData[i + 2])));

            List<string> cbBTypes = people.SelectMany(p => p.busies).Select(b => b.discipline).Distinct().Except(new string[] { "-" }).ToList();
            cbBTypes.Insert(0, "Все");
            comboBoxDiscipline.DataSource = cbBTypes;

            UpdatePeopleList();
        }

        public void UpdatePeopleList()
        {
            listBoxPeople.DataSource = null;

            string discipline = (string)comboBoxDiscipline.SelectedItem;
            string type = (string)comboBoxType.SelectedItem;
            if (discipline == "Все")
                listBoxPeople.DataSource = people;
            else if (type == "Все")
                listBoxPeople.DataSource = people.Where(p => p.busies.Any(b => b.discipline == discipline)).ToList();
            else
                listBoxPeople.DataSource = people.Where(p => p.busies.Any(b => b.discipline == discipline && b.TypeToString() == type)).ToList();
        }

        private void listBoxPeople_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            listBoxBusyness.DataSource = null;
            Person person = (Person)listBoxPeople.SelectedItem;
            if (person == null)
                return;

            comboBoxBusyType.DataSource = null;
            comboBoxBusyType.DataSource = (new string[] { "Все" }).Concat(person.busies.Select(b => b.TypeToString())).Distinct().ToList();
            listBoxBusyness.DataSource = ((Person)listBoxPeople.SelectedItem).busies;
        }

        private void comboBoxDiscipline_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (comboBoxDiscipline.SelectedItem == null)
                return;

            UpdatePeopleList();
        }

        private void comboBoxType_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (comboBoxType.SelectedItem == null)
                return;

            UpdatePeopleList();
        }

        private void comboBoxBusyType_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (listBoxPeople.SelectedItem == null)
                return;

            string type = (string)comboBoxBusyType.SelectedItem;
            if (type == "Все")
                listBoxBusyness.DataSource = ((Person)listBoxPeople.SelectedItem).busies;
            else
                listBoxBusyness.DataSource = ((Person)listBoxPeople.SelectedItem).busies.Where(b => b.TypeToString() == type).ToList();
        }
    }
}