﻿namespace LINQ
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxPeople = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxBusyType = new System.Windows.Forms.ComboBox();
            this.listBoxBusyness = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxDiscipline = new System.Windows.Forms.ComboBox();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDownHpM = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxDisciplineName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxBusyEdit = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonTeacher = new System.Windows.Forms.RadioButton();
            this.radioButtonEngineer = new System.Windows.Forms.RadioButton();
            this.buttonPersonAdd = new System.Windows.Forms.Button();
            this.buttonPersonDell = new System.Windows.Forms.Button();
            this.buttonPersonEdit = new System.Windows.Forms.Button();
            this.buttonBusyEdit = new System.Windows.Forms.Button();
            this.buttonBusyDel = new System.Windows.Forms.Button();
            this.buttonBusyAdd = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHpM)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxPeople
            // 
            this.listBoxPeople.FormattingEnabled = true;
            this.listBoxPeople.ItemHeight = 16;
            this.listBoxPeople.Location = new System.Drawing.Point(13, 77);
            this.listBoxPeople.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxPeople.Name = "listBoxPeople";
            this.listBoxPeople.Size = new System.Drawing.Size(820, 260);
            this.listBoxPeople.TabIndex = 0;
            this.listBoxPeople.SelectedIndexChanged += new System.EventHandler(this.listBoxPeople_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Преподаватели и инженеры кафедры:";
            // 
            // comboBoxBusyType
            // 
            this.comboBoxBusyType.FormattingEnabled = true;
            this.comboBoxBusyType.Location = new System.Drawing.Point(558, 382);
            this.comboBoxBusyType.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxBusyType.Name = "comboBoxBusyType";
            this.comboBoxBusyType.Size = new System.Drawing.Size(275, 24);
            this.comboBoxBusyType.TabIndex = 3;
            this.comboBoxBusyType.SelectedIndexChanged += new System.EventHandler(this.comboBoxBusyType_SelectedIndexChanged);
            // 
            // listBoxBusyness
            // 
            this.listBoxBusyness.FormattingEnabled = true;
            this.listBoxBusyness.HorizontalScrollbar = true;
            this.listBoxBusyness.ItemHeight = 16;
            this.listBoxBusyness.Location = new System.Drawing.Point(13, 410);
            this.listBoxBusyness.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxBusyness.Name = "listBoxBusyness";
            this.listBoxBusyness.Size = new System.Drawing.Size(820, 276);
            this.listBoxBusyness.TabIndex = 4;
            this.listBoxBusyness.SelectedIndexChanged += new System.EventHandler(this.listBoxBusyness_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(407, 385);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Фильтрация по типу:";
            // 
            // comboBoxDiscipline
            // 
            this.comboBoxDiscipline.FormattingEnabled = true;
            this.comboBoxDiscipline.Location = new System.Drawing.Point(103, 22);
            this.comboBoxDiscipline.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxDiscipline.Name = "comboBoxDiscipline";
            this.comboBoxDiscipline.Size = new System.Drawing.Size(160, 24);
            this.comboBoxDiscipline.TabIndex = 6;
            this.comboBoxDiscipline.SelectedIndexChanged += new System.EventHandler(this.comboBoxDiscipline_SelectedIndexChanged);
            // 
            // comboBoxType
            // 
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Items.AddRange(new object[] {
            "Все",
            "Лекция",
            "Практика",
            "Лабораторная работа"});
            this.comboBoxType.Location = new System.Drawing.Point(369, 22);
            this.comboBoxType.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(160, 24);
            this.comboBoxType.TabIndex = 7;
            this.comboBoxType.SelectedIndexChanged += new System.EventHandler(this.comboBoxType_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Дисциплина:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(271, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Вид занятий:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 390);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(265, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Занятость выбранного преподавателя:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(9, 100);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(288, 22);
            this.textBoxName.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Ф.И.О.";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonBusyEdit);
            this.groupBox1.Controls.Add(this.buttonBusyDel);
            this.groupBox1.Controls.Add(this.buttonBusyAdd);
            this.groupBox1.Controls.Add(this.numericUpDownHpM);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBoxDisciplineName);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.comboBoxBusyEdit);
            this.groupBox1.Location = new System.Drawing.Point(840, 410);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(306, 276);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Выбранная занятость";
            // 
            // numericUpDownHpM
            // 
            this.numericUpDownHpM.Location = new System.Drawing.Point(9, 190);
            this.numericUpDownHpM.Name = "numericUpDownHpM";
            this.numericUpDownHpM.Size = new System.Drawing.Size(288, 22);
            this.numericUpDownHpM.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 171);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Часов в месяц";
            // 
            // textBoxDisciplineName
            // 
            this.textBoxDisciplineName.Location = new System.Drawing.Point(9, 126);
            this.textBoxDisciplineName.Name = "textBoxDisciplineName";
            this.textBoxDisciplineName.Size = new System.Drawing.Size(288, 22);
            this.textBoxDisciplineName.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Дисциплина";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Тип";
            // 
            // comboBoxBusyEdit
            // 
            this.comboBoxBusyEdit.FormattingEnabled = true;
            this.comboBoxBusyEdit.Items.AddRange(new object[] {
            "Научно-исследовательская работа",
            "Организационная работа",
            "Методическая работа",
            "Лекция",
            "Практика",
            "Лабораторная работа"});
            this.comboBoxBusyEdit.Location = new System.Drawing.Point(9, 53);
            this.comboBoxBusyEdit.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxBusyEdit.Name = "comboBoxBusyEdit";
            this.comboBoxBusyEdit.Size = new System.Drawing.Size(288, 24);
            this.comboBoxBusyEdit.TabIndex = 16;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonPersonEdit);
            this.groupBox2.Controls.Add(this.buttonPersonDell);
            this.groupBox2.Controls.Add(this.buttonPersonAdd);
            this.groupBox2.Controls.Add(this.radioButtonEngineer);
            this.groupBox2.Controls.Add(this.radioButtonTeacher);
            this.groupBox2.Controls.Add(this.textBoxName);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(840, 77);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(306, 260);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Выбранный преподаватель";
            // 
            // radioButtonTeacher
            // 
            this.radioButtonTeacher.AutoSize = true;
            this.radioButtonTeacher.Location = new System.Drawing.Point(9, 143);
            this.radioButtonTeacher.Name = "radioButtonTeacher";
            this.radioButtonTeacher.Size = new System.Drawing.Size(132, 20);
            this.radioButtonTeacher.TabIndex = 14;
            this.radioButtonTeacher.TabStop = true;
            this.radioButtonTeacher.Text = "Преподаватель";
            this.radioButtonTeacher.UseVisualStyleBackColor = true;
            // 
            // radioButtonEngineer
            // 
            this.radioButtonEngineer.AutoSize = true;
            this.radioButtonEngineer.Location = new System.Drawing.Point(210, 143);
            this.radioButtonEngineer.Name = "radioButtonEngineer";
            this.radioButtonEngineer.Size = new System.Drawing.Size(87, 20);
            this.radioButtonEngineer.TabIndex = 15;
            this.radioButtonEngineer.TabStop = true;
            this.radioButtonEngineer.Text = "Инженер";
            this.radioButtonEngineer.UseVisualStyleBackColor = true;
            // 
            // buttonPersonAdd
            // 
            this.buttonPersonAdd.Location = new System.Drawing.Point(205, 231);
            this.buttonPersonAdd.Name = "buttonPersonAdd";
            this.buttonPersonAdd.Size = new System.Drawing.Size(92, 23);
            this.buttonPersonAdd.TabIndex = 16;
            this.buttonPersonAdd.Text = "Добавить";
            this.buttonPersonAdd.UseVisualStyleBackColor = true;
            this.buttonPersonAdd.Click += new System.EventHandler(this.buttonPersonAdd_Click);
            // 
            // buttonPersonDell
            // 
            this.buttonPersonDell.Location = new System.Drawing.Point(9, 231);
            this.buttonPersonDell.Name = "buttonPersonDell";
            this.buttonPersonDell.Size = new System.Drawing.Size(92, 23);
            this.buttonPersonDell.TabIndex = 17;
            this.buttonPersonDell.Text = "Удалить";
            this.buttonPersonDell.UseVisualStyleBackColor = true;
            this.buttonPersonDell.Click += new System.EventHandler(this.buttonPersonDell_Click);
            // 
            // buttonPersonEdit
            // 
            this.buttonPersonEdit.Location = new System.Drawing.Point(107, 231);
            this.buttonPersonEdit.Name = "buttonPersonEdit";
            this.buttonPersonEdit.Size = new System.Drawing.Size(92, 23);
            this.buttonPersonEdit.TabIndex = 18;
            this.buttonPersonEdit.Text = "Изменить";
            this.buttonPersonEdit.UseVisualStyleBackColor = true;
            this.buttonPersonEdit.Click += new System.EventHandler(this.buttonPersonEdit_Click);
            // 
            // buttonBusyEdit
            // 
            this.buttonBusyEdit.Location = new System.Drawing.Point(107, 247);
            this.buttonBusyEdit.Name = "buttonBusyEdit";
            this.buttonBusyEdit.Size = new System.Drawing.Size(92, 23);
            this.buttonBusyEdit.TabIndex = 24;
            this.buttonBusyEdit.Text = "Изменить";
            this.buttonBusyEdit.UseVisualStyleBackColor = true;
            this.buttonBusyEdit.Click += new System.EventHandler(this.buttonBusyEdit_Click);
            // 
            // buttonBusyDel
            // 
            this.buttonBusyDel.Location = new System.Drawing.Point(9, 247);
            this.buttonBusyDel.Name = "buttonBusyDel";
            this.buttonBusyDel.Size = new System.Drawing.Size(92, 23);
            this.buttonBusyDel.TabIndex = 23;
            this.buttonBusyDel.Text = "Удалить";
            this.buttonBusyDel.UseVisualStyleBackColor = true;
            this.buttonBusyDel.Click += new System.EventHandler(this.buttonBusyDel_Click);
            // 
            // buttonBusyAdd
            // 
            this.buttonBusyAdd.Location = new System.Drawing.Point(205, 247);
            this.buttonBusyAdd.Name = "buttonBusyAdd";
            this.buttonBusyAdd.Size = new System.Drawing.Size(92, 23);
            this.buttonBusyAdd.TabIndex = 22;
            this.buttonBusyAdd.Text = "Добавить";
            this.buttonBusyAdd.UseVisualStyleBackColor = true;
            this.buttonBusyAdd.Click += new System.EventHandler(this.buttonBusyAdd_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBoxType);
            this.groupBox3.Controls.Add(this.comboBoxDiscipline);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(295, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(538, 58);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Поиск преподавателя";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1154, 699);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxBusyness);
            this.Controls.Add(this.comboBoxBusyType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxPeople);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "Задание №19 выполнил: Голюбдин А.В., Номер варианта: 3 Дата выполнения: 11/12/202" +
    "4";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHpM)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxPeople;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxBusyType;
        private System.Windows.Forms.ListBox listBoxBusyness;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxDiscipline;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxBusyEdit;
        private System.Windows.Forms.TextBox textBoxDisciplineName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDownHpM;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonBusyEdit;
        private System.Windows.Forms.Button buttonBusyDel;
        private System.Windows.Forms.Button buttonBusyAdd;
        private System.Windows.Forms.Button buttonPersonEdit;
        private System.Windows.Forms.Button buttonPersonDell;
        private System.Windows.Forms.Button buttonPersonAdd;
        private System.Windows.Forms.RadioButton radioButtonEngineer;
        private System.Windows.Forms.RadioButton radioButtonTeacher;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

