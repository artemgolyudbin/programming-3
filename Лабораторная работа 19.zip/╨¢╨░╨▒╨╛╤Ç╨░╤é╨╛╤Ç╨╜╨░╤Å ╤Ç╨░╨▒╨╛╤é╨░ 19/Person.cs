﻿using System.Collections.Generic;
using System.Linq;

namespace LINQ
{
    public class Person
    {
        public string Name { get; private set; }
        public bool isTeacher { get; private set; }
        public List<BusyType> busies = new List<BusyType>();

        public Person(string name, bool isTeacher)
        {
            Name = name;
            this.isTeacher = isTeacher;
        }

        public override string ToString()
        {
            return (isTeacher ? "Преподаватель " : "Инженер ") + Name + " Всего ч/м: " + busies.Sum(b => b.hoursPerMonth);
        }
    }
}
