﻿namespace LINQ
{
    public class BusyType
    {
        public enum Type { ScienseWork, Management, Metodical, Lecture, Practice, LabWork }
        
        public Type type { get; set; }
        public string discipline { get; set; }
        public int hoursPerMonth { get; set; }

        public BusyType(Type type, string discipline, int hoursPerMonth)
        {
            this.type = type;
            this.discipline = discipline;
            this.hoursPerMonth = hoursPerMonth;
        }

        public string TypeToString()
        {
            if (type == Type.ScienseWork)
                return "Научно-исследовательская работа";
            else if (type == Type.Management)
                return "Организационная работа";
            else if (type == Type.Metodical)
                return "Методическая работа";
            else if (type == Type.Lecture)
                return "Лекция";
            else if (type == Type.Practice)
                return "Практика";
            else if (type == Type.LabWork)
                return "Лабораторная работа";

            return "NotFound";
        }

        public override string ToString()
        {
            return TypeToString() + ", " + discipline + ". " + hoursPerMonth + "ч/м";
        }
    }
}